package com.example.SpringClase2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringClase2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
