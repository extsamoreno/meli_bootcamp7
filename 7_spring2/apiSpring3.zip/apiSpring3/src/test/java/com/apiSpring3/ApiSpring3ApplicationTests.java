package com.apiSpring3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSpring3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
