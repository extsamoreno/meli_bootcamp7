package com.apiSpring3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSpring3Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiSpring3Application.class, args);
	}

}
