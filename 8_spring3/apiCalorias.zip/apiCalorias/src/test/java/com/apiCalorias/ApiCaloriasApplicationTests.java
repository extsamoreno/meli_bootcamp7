package com.apiCalorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCaloriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
