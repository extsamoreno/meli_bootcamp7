package meli.springchallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringchallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringchallengeApplication.class, args);
	}

}
