package Exercise1;

public interface Precedable<T>{
    public int precedeA(T t);
}