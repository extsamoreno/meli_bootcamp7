package com.example.testingchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingchallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
