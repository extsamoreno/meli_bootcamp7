package com.example.testingchallengev2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Testingchallengev2Application {

	public static void main(String[] args) {
		SpringApplication.run(Testingchallengev2Application.class, args);
	}

}
