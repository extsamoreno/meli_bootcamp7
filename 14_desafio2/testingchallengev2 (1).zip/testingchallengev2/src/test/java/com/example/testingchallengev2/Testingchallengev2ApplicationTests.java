package com.example.testingchallengev2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Testingchallengev2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
