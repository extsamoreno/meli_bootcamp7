package meli.ejerc1;

public class PasswordIntermedia extends Password
{
}
