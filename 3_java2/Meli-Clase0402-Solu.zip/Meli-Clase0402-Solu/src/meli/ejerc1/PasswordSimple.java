package meli.ejerc1;

public class PasswordSimple extends Password
{
}
