package meli.ejerc1;

public class Password
{
}
