package meli.ejerc2;

public abstract class FiguraGeometrica
{

}
