package meli.ejerc2;

public class FiguraUtil
{
	public static double areaPromedio(FiguraGeometrica[] arr)
	{
		return 0;
	}
}
