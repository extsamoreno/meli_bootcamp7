package meli.ejerc2;

public class Circulo extends FiguraGeometrica
{

}
