package meli.ejerc2;

public class Triangulo extends FiguraGeometrica
{

}
