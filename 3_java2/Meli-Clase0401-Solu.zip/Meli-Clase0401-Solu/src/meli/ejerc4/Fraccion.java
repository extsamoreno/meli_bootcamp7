package meli.ejerc4;

public class Fraccion
{
}
