package meli.ejerc2;

public class Contador
{
	private int cont=0;

	public Contador(){this(0);}	
	public Contador(Contador c){this(c.cont);} 
	public Contador(int vInic){this.cont=vInic;}

	public void incre(){this.cont++;}
	public void decre(){this.cont--;}
}
