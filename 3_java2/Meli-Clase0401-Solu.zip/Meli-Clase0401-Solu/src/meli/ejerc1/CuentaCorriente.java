package meli.ejerc1;

public class CuentaCorriente
{
	private double saldo=0;
	private String nro="";
	
	public CuentaCorriente(){}
	public CuentaCorriente(String nro,double d)
	{
		this.nro=nro;
		this.saldo=d;
	}

	public CuentaCorriente(CuentaCorriente cc)
	{
		this(cc.nro,cc.saldo);
	}
		
	public void ingreso(double d)
	{
		this.saldo+=d;
	}
	
	public void egreso(double d)
	{
		this.saldo-=d;
	}
	
	public void reintegro(double d)
	{
		this.saldo+=d;
	}
	
	public void transferencia(double d,CuentaCorriente ccDest)
	{
		this.saldo-=d;
		ccDest.saldo+=d;
	}
	
	public double getSaldo()
	{
		return saldo;
	}
	public void setSaldo(double saldo)
	{
		this.saldo=saldo;
	}
	public String getNro()
	{
		return nro;
	}
	public void setNro(String nro)
	{
		this.nro=nro;
	}
}
