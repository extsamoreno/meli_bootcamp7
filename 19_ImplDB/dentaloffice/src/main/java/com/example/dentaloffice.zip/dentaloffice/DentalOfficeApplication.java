package com.example.dentaloffice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentalOfficeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DentalOfficeApplication.class, args);
	}

}
