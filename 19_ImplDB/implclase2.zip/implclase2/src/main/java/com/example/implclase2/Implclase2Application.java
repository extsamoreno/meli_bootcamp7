package com.example.implclase2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Implclase2Application {

	public static void main(String[] args) {
		SpringApplication.run(Implclase2Application.class, args);
	}

}
