package com.example.diplomatesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomatestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
