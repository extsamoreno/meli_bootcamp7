package com.example.diplomatesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomatestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplomatestingApplication.class, args);
	}

}
