package com.example.springclase4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springclase4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
