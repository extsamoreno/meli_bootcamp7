package com.example.API_numeros_romanos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiNumerosRomanosApplicationTests {

	@Test
	void contextLoads() {
	}

}
